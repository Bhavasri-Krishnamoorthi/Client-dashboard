import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

function MainLayout({ children }) {
  return (
    <>
      <Sidebar />

      <div
       style={{
  marginLeft: window.innerWidth <= 768 ? "0" : "340px",
  padding: window.innerWidth <= 768 ? "10px" : "20px",
  minHeight: "100vh",
}}
      >
        <Navbar />

        <div
          style={{
            marginTop: "25px",
            paddingBottom: "30px",
          }}
        >
          {children}
        </div>
      </div>
    </>
  );
}

export default MainLayout;